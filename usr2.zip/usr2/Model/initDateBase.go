package Model

import (
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"log"
)

var db *gorm.DB //数据库指针

//初始化数据库
func init() {
	var err error

	dsn := "xds:Qq3318055.@tcp(114.115.176.43:3306)/xdstest?parseTime=true"

	db, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})

	if err != nil {
		log.Fatal(err)
	}

	//自动迁移
	db.AutoMigrate(&Uav{}, &Record{}, &User{})
}
