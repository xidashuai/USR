package Model

import (
	"context"
	"encoding/base64"
	"fmt"
	"github.com/chromedp/cdproto/cdp"
	"github.com/chromedp/chromedp"
	"github.com/gin-gonic/gin"
	"github.com/huaweicloud/huaweicloud-sdk-go-v3/core/auth/basic"
	ocr "github.com/huaweicloud/huaweicloud-sdk-go-v3/services/ocr/v1"
	"github.com/huaweicloud/huaweicloud-sdk-go-v3/services/ocr/v1/model"
	"github.com/huaweicloud/huaweicloud-sdk-go-v3/services/ocr/v1/region"
	"io/ioutil"
	"log"
	"time"
)

func JWXT(contextt *gin.Context)  {
    id:=contextt.PostForm("schoolid")
	psw:=contextt.PostForm("password")
fmt.Println(psw)

	opts := append(chromedp.DefaultExecAllocatorOptions[:],
	//	chromedp.Flag("headless", false),
	)
	allocCtx, cancel := chromedp.NewExecAllocator(context.Background(), opts...)
	defer cancel()

	// create chrome instance
	ctx, cancel := chromedp.NewContext(
		allocCtx,
		chromedp.WithLogf(log.Printf),
	)
	defer cancel()

	// create a timeout
	ctx, cancel = context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	chromedp.Run(ctx,
		chromedp.Navigate(`http://auth-sztu-edu-cn-s.webvpn.sztu.edu.cn:8118/idp/authcenter/ActionAuthChain?entityId=webvpn`),
		chromedp.Sleep(2*time.Second),
		//缓一缓
		chromedp.Click(`//*[@id="app_dialog_container"]/div[2]/div/div[2]/div/div[4]/div/button`),
		chromedp.Sleep(2*time.Second),
		chromedp.SendKeys(`//*[@id="j_username"]`,id,chromedp.BySearch),
		chromedp.SendKeys(`//*[@id="j_password"]`,psw,chromedp.BySearch),
		getCode(contextt),
		//	 chromedp.Click(`/html/body/div[3]/div/div[1]/div[4]/form/button`),

	)


}


func getCode(contextt *gin.Context ) chromedp.ActionFunc {
	return func(ctx context.Context) (err error) {
		ak := "MW8HVQTXAFYRNZL9CEEY"
		sk := "5qzLdig5nLVJ5Y66bEjEaW8VdOgIFEamNLAYehQY"
		auth := basic.NewCredentialsBuilder().
			WithAk(ak).
			WithSk(sk).
			Build()

		client := ocr.NewOcrClient(
			ocr.OcrClientBuilder().
				WithRegion(region.ValueOf("cn-north-4")).
				WithCredential(auth).
				Build())
		// 1. 用于存储图片的字节切片
		var code []byte
		var nodes []*cdp.Node
		//chromedp.Click(`/html/body/div[3]/div/div[1]/div[4]/form/button`).Do(ctx)
		chromedp.Nodes(`#j_checkcodeImgCode1`, &nodes).Do(ctx)
		cnt := len(nodes[0].Attributes)
		// 2. 截图
		// 注意这里需要注明直接使用ID选择器来获取元素（chromedp.ByID）
		if cnt == 4 {
			var nodes1 []*cdp.Node
			chromedp.Click(`/html/body/div[3]/div/div[1]/div[4]/form/button`).Do(ctx)
			chromedp.Sleep(2 * time.Second).Do(ctx)
			chromedp.Nodes(`/html/head/title`, &nodes1).Do(ctx)
			fmt.Println(nodes1[0].Children[0].NodeValue)
			if nodes1[0].Children[0].NodeValue!="系统登录" {
				contextt.JSON(200,map[string]string{
					"msg":"登录成功",
				})
			}else {
				contextt.JSON(200,map[string]string{
					"msg":"登录失败，学号/密码错误",
				})
			}
		} else {
			chromedp.Sleep(3*time.Second).Do(ctx)
			chromedp.Screenshot(`#j_checkcodeImgCode1`, &code, chromedp.ByID).Do(ctx)
			//	chromedp.Sleep(2*time.Second).Do(ctx)

			str := base64.StdEncoding.EncodeToString(code)
			// 3. 保存文件
			if err = ioutil.WriteFile("code.png", code, 0755); err == nil {
				request := &model.RecognizeGeneralTextRequest{}
				//urlGeneralTableRequestBody:= "图片的url"

				sd  :=false
				//url:="https://auth.sztu.edu.cn/idp/Kaptcha.jpg?dt=1651398557639"
				request.Body = &model.GeneralTextRequestBody{
					Image: &str,
					//	  Url:          &url,
					DetectDirection:  &sd,
					QuickMode:        &sd,
				}
				response, err1 := client.RecognizeGeneralText(request)
				if err1 == nil {
					fmt.Printf("%+v\n", response)
					str1 := response.Result.String()
					str2:=str1[86:90]
					log.Printf(str2)
					chromedp.SendKeys(`//*[@id="j_checkcode"]`,str2,chromedp.BySearch).Do(ctx)
					chromedp.Sleep(1*time.Second).Do(ctx)
					//chromedp.Click(`/html/body/div[3]/div/div[1]/div[4]/form/button`).Do(ctx)
					var nodes1 []*cdp.Node
					chromedp.Nodes(`/html/head/title`, &nodes1).Do(ctx)
					fmt.Println(nodes1[0].Children[0].NodeValue)
					if nodes1[0].Children[0].NodeValue!="系统登录" {
						contextt.JSON(200,map[string]string{
							"msg":"登录成功",
						})
					}else {
						contextt.JSON(200,map[string]string{
							"msg":"登录失败，学号/密码错误",
						})
					}
				} else {
					fmt.Println(err)
				}
			}

		}
		return
	}
}
